#include "EchoLib.h"

namespace EchoLib {
  void begin() {
    // Initialization code will go here later
  }
}
